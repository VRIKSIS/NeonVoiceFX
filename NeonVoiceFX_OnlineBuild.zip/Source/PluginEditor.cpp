#include "PluginEditor.h"

namespace {
const juce::Colour bg(0xff020b05), panel(0xff041b0c), green(0xff54ff68), muted(0xff7b9c82);
}
NeonVoiceFXAudioProcessorEditor::NeonVoiceFXAudioProcessorEditor(NeonVoiceFXAudioProcessor& p)
: AudioProcessorEditor(&p), audioProcessor(p)
{
    setSize(900, 610);
    title.setText("NEON VOICE FX", juce::dontSendNotification);
    title.setFont(juce::Font(juce::FontOptions(25.0f, juce::Font::bold)));
    title.setColour(juce::Label::textColourId, green);
    addAndMakeVisible(title);
    subtitle.setText("VOICE PROCESSING  /  VST3", juce::dontSendNotification);
    subtitle.setFont(juce::Font(juce::FontOptions(11.0f)));
    subtitle.setColour(juce::Label::textColourId, muted);
    addAndMakeVisible(subtitle);

    addKnob("low","LOW"); addKnob("mid","MID"); addKnob("high","HIGH");
    addKnob("comp","COMP"); addKnob("sat","SATURATION"); addKnob("dist","DISTORTION");
    addKnob("d1mix","DLY 1 MIX"); addKnob("d1time","DLY 1 TIME"); addKnob("d1fb","FEEDBACK");
    addKnob("d1cut","CUTOFF"); addKnob("d2mix","DLY 2 MIX"); addKnob("d2time","DLY 2 TIME");
    addKnob("panrate","PAN RATE"); addKnob("panwidth","PAN WIDTH");
    addToggle("madk1d","MADK1D"); addToggle("monosat","MONO / SAT"); addToggle("deep","DEEP VOICE");
}
void NeonVoiceFXAudioProcessorEditor::addKnob(const juce::String& id, const juce::String& name)
{
    auto k = std::make_unique<Knob>();
    k->slider.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
    k->slider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 66, 18);
    k->slider.setColour(juce::Slider::rotarySliderFillColourId, green);
    k->slider.setColour(juce::Slider::rotarySliderOutlineColourId, juce::Colour(0xff183d23));
    k->slider.setColour(juce::Slider::thumbColourId, green);
    k->slider.setColour(juce::Slider::textBoxTextColourId, juce::Colours::white);
    k->slider.setColour(juce::Slider::textBoxBackgroundColourId, bg);
    k->slider.setColour(juce::Slider::textBoxOutlineColourId, juce::Colour(0xff194b27));
    k->label.setText(name, juce::dontSendNotification);
    k->label.setJustificationType(juce::Justification::centred);
    k->label.setFont(juce::Font(juce::FontOptions(10.5f, juce::Font::bold)));
    k->label.setColour(juce::Label::textColourId, juce::Colours::white);
    k->attachment = std::make_unique<SliderAttachment>(audioProcessor.parameters, id, k->slider);
    addAndMakeVisible(k->slider); addAndMakeVisible(k->label);
    knobs.push_back(std::move(k));
}
void NeonVoiceFXAudioProcessorEditor::addToggle(const juce::String& id, const juce::String& name)
{
    auto t = std::make_unique<Toggle>();
    t->button.setButtonText(name);
    t->button.setColour(juce::ToggleButton::textColourId, juce::Colours::white);
    t->button.setColour(juce::ToggleButton::tickColourId, green);
    t->attachment = std::make_unique<ButtonAttachment>(audioProcessor.parameters, id, t->button);
    addAndMakeVisible(t->button);
    toggles.push_back(std::move(t));
}
void NeonVoiceFXAudioProcessorEditor::paint(juce::Graphics& g)
{
    g.fillAll(bg);
    g.setColour(juce::Colour(0xff0b2913)); g.fillRoundedRectangle(12, 60, 876, 155, 8);
    g.fillRoundedRectangle(12, 225, 876, 100, 8);
    g.fillRoundedRectangle(12, 335, 876, 160, 8);
    g.fillRoundedRectangle(12, 505, 876, 92, 8);
    g.setColour(green.withAlpha(0.65f)); g.drawRoundedRectangle(12,60,876,155,8,1.5f);
    g.drawRoundedRectangle(12,225,876,100,8,1.5f);
    g.drawRoundedRectangle(12,335,876,160,8,1.5f);
    g.drawRoundedRectangle(12,505,876,92,8,1.5f);
    g.setColour(green);
    g.setFont(juce::Font(juce::FontOptions(11.0f, juce::Font::bold)));
    g.drawText("01  /  EQUALIZER", 24, 64, 180, 18, juce::Justification::left);
    g.drawText("02  /  DYNAMICS + DRIVE", 24, 229, 250, 18, juce::Justification::left);
    g.drawText("03  /  DUAL DELAY", 24, 339, 200, 18, juce::Justification::left);
    g.drawText("04  /  MOVEMENT + VOICE MODES", 24, 509, 300, 18, juce::Justification::left);
}
void NeonVoiceFXAudioProcessorEditor::resized()
{
    title.setBounds(20, 8, 360, 32); subtitle.setBounds(22, 36, 300, 18);
    auto place = [this](int idx, int x, int y, int w, int h) {
        auto& k = *knobs[(size_t)idx];
        k.label.setBounds(x, y, w, 18);
        k.slider.setBounds(x, y+18, w, h-18);
    };
    place(0,30,82,125,120); place(1,165,82,125,120); place(2,300,82,125,120);
    place(3,35,247,125,70); place(4,180,247,125,70); place(5,325,247,125,70);
    place(6,30,357,125,125); place(7,165,357,125,125); place(8,300,357,125,125);
    place(9,435,357,125,125); place(10,570,357,125,125); place(11,705,357,125,125);
    place(12,575,82,125,120); place(13,710,82,125,120);
    for (int i=0;i<(int)toggles.size();++i)
        toggles[(size_t)i]->button.setBounds(30+i*270, 535, 230, 42);
}
