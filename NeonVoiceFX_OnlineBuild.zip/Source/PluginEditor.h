#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"

class NeonVoiceFXAudioProcessorEditor : public juce::AudioProcessorEditor
{
public:
    explicit NeonVoiceFXAudioProcessorEditor(NeonVoiceFXAudioProcessor&);
    ~NeonVoiceFXAudioProcessorEditor() override = default;
    void paint(juce::Graphics&) override;
    void resized() override;
private:
    using SliderAttachment = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ButtonAttachment = juce::AudioProcessorValueTreeState::ButtonAttachment;
    NeonVoiceFXAudioProcessor& audioProcessor;
    juce::Label title;
    juce::Label subtitle;
    struct Knob {
        juce::Slider slider;
        juce::Label label;
        std::unique_ptr<SliderAttachment> attachment;
    };
    std::vector<std::unique_ptr<Knob>> knobs;
    struct Toggle {
        juce::ToggleButton button;
        std::unique_ptr<ButtonAttachment> attachment;
    };
    std::vector<std::unique_ptr<Toggle>> toggles;
    void addKnob(const juce::String& id, const juce::String& name);
    void addToggle(const juce::String& id, const juce::String& name);
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (NeonVoiceFXAudioProcessorEditor)
};
