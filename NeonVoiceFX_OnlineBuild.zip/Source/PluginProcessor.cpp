#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <cmath>

namespace
{
    constexpr float pi = 3.14159265358979323846f;
    float dbToGain(float db) { return std::pow(10.0f, db / 20.0f); }
    float clamp01(float x) { return juce::jlimit(0.0f, 1.0f, x); }
}

NeonVoiceFXAudioProcessor::NeonVoiceFXAudioProcessor()
: AudioProcessor(BusesProperties().withInput("Input", juce::AudioChannelSet::stereo(), true)
                                .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
  parameters(*this, nullptr, "PARAMETERS", createParameterLayout())
{
}

NeonVoiceFXAudioProcessor::APVTS::ParameterLayout NeonVoiceFXAudioProcessor::createParameterLayout()
{
    APVTS::ParameterLayout p;
    auto knob = [&p](const char* id, const char* name, float lo, float hi, float def, float step = 0.0f) {
        p.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{id, 1}, name,
            juce::NormalisableRange<float>(lo, hi, step), def));
    };
    auto toggle = [&p](const char* id, const char* name, bool def = false) {
        p.add(std::make_unique<juce::AudioParameterBool>(juce::ParameterID{id, 1}, name, def));
    };
    knob("low", "Low", -12, 12, 0); knob("mid", "Mid", -12, 12, 0); knob("high", "High", -12, 12, 0);
    knob("comp", "Compression", 0, 100, 25); knob("sat", "Saturation", 0, 100, 12);
    knob("dist", "Distortion", 0, 100, 0);
    knob("d1mix", "Delay 1 Mix", 0, 100, 0); knob("d1time", "Delay 1 Time", 30, 1200, 280);
    knob("d1fb", "Delay 1 Feedback", 0, 90, 28); knob("d1cut", "Delay 1 Tone", 500, 16000, 9000);
    knob("d2mix", "Delay 2 Mix", 0, 100, 0); knob("d2time", "Delay 2 Time", 10, 500, 95);
    knob("panrate", "Auto Pan Rate", 0.05f, 8, 0.4f); knob("panwidth", "Auto Pan Width", 0, 100, 0);
    toggle("madk1d", "MADK1D Mode"); toggle("monosat", "MONO / SAT"); toggle("deep", "DEEP VOICE");
    return p;
}

void NeonVoiceFXAudioProcessor::prepareToPlay(double sampleRate, int samplesPerBlock)
{
    sr = sampleRate;
    const int maxDelay = juce::jmax(2, (int) std::ceil(sr * 1.5));
    delayA.setSize(2, maxDelay); delayA.clear();
    delayB.setSize(2, maxDelay); delayB.clear();
    delayWriteA = delayWriteB = 0;
    lowState[0] = lowState[1] = midState[0] = midState[1] = 0.0f;
    compEnvelope[0] = compEnvelope[1] = 0.0f;
    panPhase = 0.0f;
}
void NeonVoiceFXAudioProcessor::releaseResources() {}
bool NeonVoiceFXAudioProcessor::isBusesLayoutSupported(const BusesLayout& l) const
{
    return l.getMainInputChannelSet() == juce::AudioChannelSet::stereo()
        && l.getMainOutputChannelSet() == juce::AudioChannelSet::stereo();
}
float NeonVoiceFXAudioProcessor::get(const char* id) const
{
    if (auto* v = parameters.getRawParameterValue(id)) return v->load();
    return 0.0f;
}

void NeonVoiceFXAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    const int channels = juce::jmin(2, buffer.getNumChannels());
    const int n = buffer.getNumSamples();
    const float lowDb = get("low"), midDb = get("mid"), highDb = get("high");
    const float comp = get("comp") / 100.0f, sat = get("sat") / 100.0f, dist = get("dist") / 100.0f;
    const bool mad = get("madk1d") > 0.5f, monoSat = get("monosat") > 0.5f, deep = get("deep") > 0.5f;
    const float d1mix = get("d1mix") / 100.0f, d1fb = get("d1fb") / 100.0f;
    const int d1delay = juce::jlimit(1, delayA.getNumSamples()-1, (int)(sr * get("d1time") / 1000.0f));
    const float d2mix = get("d2mix") / 100.0f;
    const int d2delay = juce::jlimit(1, delayB.getNumSamples()-1, (int)(sr * get("d2time") / 1000.0f));
    const float cutoff = get("d1cut");
    const float lowA = 1.0f - std::exp(-2.0f*pi*180.0f/(float)sr);
    const float midA = 1.0f - std::exp(-2.0f*pi*1200.0f/(float)sr);
    const float panRate = get("panrate"), panDepth = get("panwidth") / 100.0f;
    const float compAtk = std::exp(-1.0f / (0.010f * (float)sr));
    const float compRel = std::exp(-1.0f / (0.120f * (float)sr));
    const float deepGain = deep ? 1.35f : 1.0f;

    for (int i=0; i<n; ++i)
    {
        float x[2] = { buffer.getSample(0,i), channels > 1 ? buffer.getSample(1,i) : buffer.getSample(0,i) };
        float y[2] = {};
        for (int c=0; c<channels; ++c)
        {
            // Three-band tone control using low/mid one-pole splits.
            lowState[c] += lowA * (x[c] - lowState[c]);
            midState[c] += midA * (x[c] - midState[c]);
            const float lowBand = lowState[c];
            const float midBand = midState[c] - lowState[c];
            const float highBand = x[c] - midState[c];
            float v = lowBand * dbToGain(lowDb) + midBand * dbToGain(midDb) + highBand * dbToGain(highDb);

            // Simple smooth peak compressor; higher knob means stronger compression.
            const float a = std::abs(v);
            const float coeff = a > compEnvelope[c] ? compAtk : compRel;
            compEnvelope[c] = coeff * compEnvelope[c] + (1.0f-coeff) * a;
            const float threshold = 0.85f - comp * 0.62f;
            if (compEnvelope[c] > threshold && comp > 0.001f)
            {
                const float reduction = threshold + (compEnvelope[c]-threshold) * (1.0f - comp*0.82f);
                v *= reduction / juce::jmax(compEnvelope[c], 0.0001f);
            }

            // Saturation and distortion stages.
            v = (1.0f-sat*0.55f)*v + sat*0.55f*std::tanh(v*(1.0f+sat*5.0f));
            if (mad) v = std::tanh(v * 16.0f) * 0.72f;
            v = (1.0f-dist) * v + dist * std::tanh(v * (1.0f + dist*28.0f));
            if (deep) v = std::tanh(v * 1.7f) * deepGain;

            // Delay 1 with feedback and a basic one-pole tone control.
            const int readA = (delayWriteA - d1delay + delayA.getNumSamples()) % delayA.getNumSamples();
            const float echoA = delayA.getSample(c, readA);
            const float toneA = 1.0f - std::exp(-2.0f*pi*cutoff/(float)sr);
            static float toneState[2] = {};
            toneState[c] += toneA * (echoA - toneState[c]);
            delayA.setSample(c, delayWriteA, v + toneState[c] * d1fb);
            v = v * (1.0f-d1mix) + toneState[c] * d1mix;

            // Independent short delay 2.
            const int readB = (delayWriteB - d2delay + delayB.getNumSamples()) % delayB.getNumSamples();
            const float echoB = delayB.getSample(c, readB);
            delayB.setSample(c, delayWriteB, v);
            v = v * (1.0f-d2mix) + echoB * d2mix;
            y[c] = v;
        }
        delayWriteA = (delayWriteA + 1) % delayA.getNumSamples();
        delayWriteB = (delayWriteB + 1) % delayB.getNumSamples();

        if (channels > 1 && monoSat)
        {
            const float mono = 0.5f * (y[0] + y[1]);
            y[0] = y[1] = std::tanh(mono * 1.6f);
        }
        if (channels > 1 && panDepth > 0.001f)
        {
            const float lfo = std::sin(panPhase);
            const float leftGain = 1.0f - panDepth * (0.5f + 0.5f*lfo);
            const float rightGain = 1.0f - panDepth * (0.5f - 0.5f*lfo);
            y[0] *= leftGain; y[1] *= rightGain;
            panPhase += 2.0f*pi*panRate/(float)sr;
            if (panPhase > 2.0f*pi) panPhase -= 2.0f*pi;
        }
        for (int c=0; c<channels; ++c) buffer.setSample(c,i,y[c]);
    }
    // Keep any extra output channels silent.
    for (int c=channels; c<buffer.getNumChannels(); ++c) buffer.clear(c,0,n);
}

juce::AudioProcessorEditor* NeonVoiceFXAudioProcessor::createEditor() { return new NeonVoiceFXAudioProcessorEditor(*this); }
void NeonVoiceFXAudioProcessor::getStateInformation(juce::MemoryBlock& dest)
{
    auto state = parameters.copyState();
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, dest);
}
void NeonVoiceFXAudioProcessor::setStateInformation(const void* data, int size)
{
    std::unique_ptr<juce::XmlElement> xml(getXmlFromBinary(data, size));
    if (xml && xml->hasTagName(parameters.state.getType()))
        parameters.replaceState(juce::ValueTree::fromXml(*xml));
}
