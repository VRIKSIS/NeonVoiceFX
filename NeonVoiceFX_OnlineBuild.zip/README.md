# Neon Voice FX — starter VST3 project

A custom JUCE audio effect project with a green control panel and these first-pass DSP modules:
- 3-band tone EQ (Low / Mid / High)
- compressor
- saturation and distortion
- independent delay 1 (time, feedback, tone/cutoff, mix)
- independent short delay 2 (time, mix)
- auto-pan (rate and width)
- MADK1D, MONO/SAT and DEEP VOICE switches

## Important status
This is **source code for a first prototype**, not a precompiled `.vst3` binary. It has not been compiled or tested in this environment. The processing is a practical starting point, not a polished mastering-grade implementation. In particular, the MONO/SAT switch combines to mono and saturates; DEEP VOICE adds a darker/heavier drive character but is not a pitch shifter/formant processor.

## Build on Windows
1. Install Visual Studio 2022 with **Desktop development with C++**.
2. Install CMake (or use the CMake bundled with Visual Studio).
3. Download JUCE from https://github.com/juce-framework/JUCE and extract/clone it into this project folder as `JUCE` (so `JUCE/CMakeLists.txt` exists).
4. Open a Developer PowerShell in this folder and run:
   ```powershell
   cmake -B build -S . -G "Visual Studio 17 2022" -A x64
   cmake --build build --config Release
   ```
5. Find the generated VST3 under a path similar to:
   `build/NeonVoiceFX_artefacts/Release/VST3/Neon Voice FX.vst3`
6. Copy the `.vst3` bundle to:
   `C:\Program Files\Common Files\VST3`
   Then rescan plugins in FL Studio.

If JUCE is elsewhere, configure with:
`cmake -B build -S . -DJUCE_DIR="C:/path/to/JUCE" -G "Visual Studio 17 2022" -A x64`

## Use in FL Studio
Add **Neon Voice FX** to one mixer insert effect slot. All processing is inside this single plugin. Save a preset from the host once built and loaded.

## Safety / audio notes
Start with the master volume low; MADK1D can be extremely aggressive. This prototype has no look-ahead limiter or oversampling, so high distortion settings may alias and create peaks. Use a limiter after it if needed.

## Build online without installing Visual Studio locally (GitHub Actions)

This project includes `.github/workflows/build-vst3.yml`. To build it on GitHub-hosted Windows:

1. Create a repository on https://github.com/new (a private repository is fine).
2. Upload the contents of this project ZIP to the repository, making sure `.github/workflows/build-vst3.yml` is included and `CMakeLists.txt` is at the repository root.
3. Open the repository's **Actions** tab and enable workflows if GitHub asks.
4. Select **Build Neon Voice FX VST3** in the left sidebar and click **Run workflow** (or make a commit/push to `main` or `master` to trigger it automatically).
5. Open the completed run and download the **NeonVoiceFX-Windows-VST3** artifact. Extract the ZIP and copy `Neon Voice FX.vst3` to `C:\Program Files\Common Files\VST3`, then rescan plugins in FL Studio.

The online build is not guaranteed to succeed on the first attempt: this is an uncompiled prototype. If the workflow fails, open the failed run and share the first relevant compiler/CMake error log so the source can be corrected. GitHub-hosted Windows runners supply the build environment; nothing needs to be compiled on your PC.
